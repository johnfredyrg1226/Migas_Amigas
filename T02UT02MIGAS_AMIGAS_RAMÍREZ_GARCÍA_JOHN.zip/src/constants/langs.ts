export const Languages = [
  {label: "Spanish", code: "es"},
  {label: "Portuguese", code: "pt"},
];

